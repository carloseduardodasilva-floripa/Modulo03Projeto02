# Modulo03Projeto02
 Projeto Avaliativo FuturoDev Modulo3 Projeto02

 Este projeto corresponde ao back-end de um sistema de lista de compras, onde será criado um sistema para atualização da Lista de Compras.

 Será composto de duas tabelas, Produto e Categoria, as quais deverão ser atualizadas e consultas através do aplicativo.

