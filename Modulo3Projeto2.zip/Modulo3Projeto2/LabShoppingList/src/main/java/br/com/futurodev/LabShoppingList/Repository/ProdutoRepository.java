package br.com.futurodev.LabShoppingList.Repository;

import br.com.futurodev.LabShoppingList.Model.Categoria;
import br.com.futurodev.LabShoppingList.Model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface ProdutoRepository extends JpaRepository<Produto, Long> {

    //@Query(value = "select p from Produto p where p.statusProduto like %"coomprado"%)
    //@Query(value = "select * from Produto")
    //ArrayList<Produto> valorTotal();

}

