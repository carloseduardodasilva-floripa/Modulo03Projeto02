package br.com.futurodev.LabShoppingList.Repository;

import br.com.futurodev.LabShoppingList.Model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface CategoriaRepository extends JpaRepository<Categoria, Long> {

   // @Query(value = " select idCategoria, nomeCategoria, descricaoCategoria from Categoria c")
   // ArrayList<Categoria> getCategoria();
}
