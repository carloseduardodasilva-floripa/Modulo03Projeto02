package br.com.futurodev.LabShoppingList.controllers;

import br.com.futurodev.LabShoppingList.Model.Categoria;
import br.com.futurodev.LabShoppingList.Model.Produto;
import br.com.futurodev.LabShoppingList.Repository.ProdutoRepository;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "Produtos")
@RestController
@RequestMapping(value = "/produto")
public class ProdutoController {
    @Autowired
    private ProdutoRepository produtoRepository;

    @ApiOperation("Incluir um Produto")
    @PostMapping(value = "/", produces = "application/json")
    public ResponseEntity<Produto> cadastrar(@RequestBody Produto produto){
        Produto prod = produtoRepository.save(produto);
        return new ResponseEntity<Produto>(prod, HttpStatus.CREATED);
    }
    @ApiOperation("Atualizar um Produto")
    @PutMapping(value = "/")
    public ResponseEntity<Produto> atualizar(@RequestBody Produto produto){
        Produto prod = produtoRepository.save(produto);
        return new ResponseEntity<Produto>(prod, HttpStatus.OK);
    }

    @ApiOperation("Deletar um Produto")
    @DeleteMapping(value = "/")
    @ResponseBody
    public ResponseEntity<String> deletar(@RequestParam Long idProduto){
        produtoRepository.deleteById(idProduto);
        return new ResponseEntity<String>("Produto Deletado", HttpStatus.OK);
    }
    @ApiOperation("Listar todos os  Produtos")
    @GetMapping(value = "/buscatodos", produces = "application/json")
    public ResponseEntity<List<Produto>> getProduto(){
        List<Produto> prod = produtoRepository.findAll();
        return new ResponseEntity<List<Produto>>(prod, HttpStatus.OK);
    }

   // @ApiOperation("Valor Totaldos Produtos Comprados")
   // @GetMapping(value = "/valorTotal", produces = "application/json")
   // public ResponseEntity<List<Produto>> valorTotal(){
   //     List<Produto> prod = produtoRepository.valorTotal();
   //     return new ResponseEntity<List<Produto>>(prod, HttpStatus.OK);
   // }
}
