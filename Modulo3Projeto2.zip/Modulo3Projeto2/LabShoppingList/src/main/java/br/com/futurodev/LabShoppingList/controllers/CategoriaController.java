package br.com.futurodev.LabShoppingList.controllers;

import br.com.futurodev.LabShoppingList.Model.Categoria;
import br.com.futurodev.LabShoppingList.Repository.CategoriaRepository;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "Categorias")
@RestController
@RequestMapping(value = "/categoria")
public class CategoriaController {

    @Autowired
    private CategoriaRepository categoriaRepository;

    @ApiOperation("Incluir uma Categoria")
    @PostMapping(value = "/", produces = "application/json")
    public ResponseEntity<Categoria> cadastrar(@RequestBody Categoria categoria){
        Categoria cat = categoriaRepository.save(categoria);
        return new ResponseEntity<Categoria>(cat, HttpStatus.CREATED);
    }
    @ApiOperation("Atualizar uma categoria")
    @PutMapping(value = "/", produces = "application/json")
    public ResponseEntity<Categoria> atualizar(@RequestBody Categoria categoria){
        Categoria cat = categoriaRepository.save(categoria);
        return new ResponseEntity<Categoria>(cat, HttpStatus.OK);
    }
    @ApiOperation("Deletar uma categoria")
    @DeleteMapping(value = "/")
    @ResponseBody
    //public ResponseEntity<String> delete(@RequestParam Long idCategoria){
    public ResponseEntity<String> deletar(@RequestParam Long idCategoria){
        categoriaRepository.deleteById(idCategoria);
        return new ResponseEntity<String>("Categoria Deletada", HttpStatus.OK);
    }
    @ApiOperation("Consultar uma categoria pelo seu id")
    @GetMapping(value = "/{idCategoria}")
    public ResponseEntity<Categoria> getCategoriaById(@PathVariable(value = "idCategoria") Long idCategoria){
        Categoria cat = categoriaRepository.findById(idCategoria).get();
        return new ResponseEntity<Categoria>(cat, HttpStatus.OK);
    }
    @ApiOperation("Listar Todas as Categorias")
    @GetMapping(value = "/buscatodas", produces = "application/json")
    public ResponseEntity<List<Categoria>> getCategoria(){
        List<Categoria> cat = categoriaRepository.findAll();
        return new ResponseEntity<List<Categoria>>(cat, HttpStatus.OK);
    }

}

